package com.example.vasugame

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
